#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bounce.h"

char *stristr(const char *String, const char *Pattern)
{
      char *pptr, *sptr, *start;
      unsigned int  slen, plen;

      for (start = (char *)String,
           pptr  = (char *)Pattern,
           slen  = strlen(String),
           plen  = strlen(Pattern);

           /* while string length not shorter than pattern length */

           slen >= plen;

           start++, slen--)
      {
            /* find start of pattern in string */
            while (toupper(*start) != toupper(*Pattern))
            {
                  start++;
                  slen--;

                  /* if pattern longer than string */

                  if (slen < plen)
                        return(NULL);
            }

            sptr = start;
            pptr = (char *)Pattern;

            while (toupper(*sptr) == toupper(*pptr))
            {
                  sptr++;
                  pptr++;

                  /* if end of pattern then pattern was found */

                  if ('\0' == *pptr)
                        return (start);
            }
      }
      return(NULL);
}



FILE * fp1=NULL;
char *Deferral;

void bounce_analysis(char *bounce,char *email,char *DeliveryNo)
{
	       
	    char *pos2,*domain;
	    int i,j,k;
	       
	    domain=strchr(email,'@');
	    if(!domain) return;

	       //ȡ�õ���ԭ�򼰷���ͳ�ƣ�
	       for(i=0;i<cause_len;i++)
	       {
	       	   
	       	   if(pos2=strchr(bounce_cause[i],'|'))  //����| 
	       	   {
	       	       char sign1[64],sign2[64];
	       	       strncpy(sign1,bounce_cause[i],pos2-bounce_cause[i]-1);
	       	       sign1[pos2-bounce_cause[i]-1]='\0';
	       	       strcpy(sign2,pos2+1);
       	       
	       	       
	       	       if(strstr(bounce,sign1) && strstr(bounce,sign2))
	       	       {
	       	           break;
	       	       }
	       	   }
	       	   else
	       	   {
	       	       if(strstr(bounce,bounce_cause[i]))
	       	       {
	       	            //printf("%s--<font color=red>%d</font><br>\r\n",bounce,i);
	       	       	    break;
	       	       }
	       	   }
	       	   
	       }
	       
	       //����ԭ�����ͳ��
	       for(j=0;j<cause_type_len;j++)
	       {
	       	  
	       	  //printf("%d<br>\r\n",i);
	       	  if(i<=bounce_type_num[j])
	       	  {
	       	     bounce_stat[j]++;
	       	     //printf("%d==%s<br>\r\n",bounce_stat[j],domain);

	       	     //������������ͳ��
	       	     //printf("%d==<br>\r\n",cur_domainlist_len);

	       	     for(k=0;k<cur_domainlist_len;k++)
	       	     {
	       	        if(strcmp(domain,cur_domainlist[k])==0)
	       	        {
	       	          bounce_stat_detail[k][j]++;
	       	          //printf("%s-%d-%d-%d<br>\r\n",domain,bounce_stat_detail[k][j],k,j);

	       	          break;
	       	        } 
	       	  	
	       	     }

	       	      break;
	       	  }
	       	  
	       	  
	       }

       	       if(fp1)
 	       {
 	       	    if(j<cause_type_len && strlen(email)+strlen(bounce)<1024)
	                fprintf(fp1,"<tr><td>%s</td><td>%s</td><td width=200>%s</td><td width=50>%s</td></tr>\r\n",email,bounce,bounce_type[j],DeliveryNo);
  	            else
	                fprintf(fp1,"<tr><td>%s</td><td>%s</td><td>&nbsp;</td><td width=50>%s</td></tr>\r\n",email,bounce,DeliveryNo);
		}

}
//////////////////////////////////////////////////
void dup_analysis(char *bounce,char *email)
{
	       
        	    //���г��ر�ǣ�ֻ�����һ��
        	    int No=1;
      		      	    
        	    char *p,*p1,*p2;
        	    char token[256]="";
        	    sprintf(token,"^%s\1",email);
        	    p=strstr(Deferral,token);
        	    if(p)
        	    {
        	    	*p='~';   //���������
		        p2=strchr(p+1,'\3');   //��ȡ����;
		        if(p2)
		        {
		            p2--;
		            p1=p2;
		            while(*p1>='0' && *p1<='9') p1--;
        		        p1++;
	    	            char lls[4]="";
		            int x=0;
		            for(p1;p1<=p2;p1++)
		                lls[x++]=*p1;
		    	    lls[x]='\0';
		            No=atoi(lls)+1;
		        }   		
		    }
		    
 	       	    char buffer[1280]="";
 	       	    if(strlen(email)+strlen(bounce)<1200)
	                sprintf(buffer,"^%s\1%s\2%d\3",email,bounce,No);
	            else
	                sprintf(buffer,"^%s\1 \2%d\3",email,bounce,No);
	                        	            	    
		    strcat(Deferral,buffer);
		    //printf("%s",buffer);
}
///////////////////////////////////////////////////

int main(int argc, char* argv[])
{

    if(argc>9) exit(2);
    	
        char x[256]="";

        char Message_ID[255]="";

        char *Username=argv[2];

        if(argv[1][0]!='/')
        {
            char *pMsgID=strchr(argv[1],'/');
            if(!pMsgID)
                pMsgID=argv[1];
            else
                pMsgID++;
        
            strcpy(Message_ID,"/var/qmail/queue/deferral/");
            strcat(Message_ID,pMsgID);

            strcpy(x,"/home/httpd/bizsky/maillist/mail/");
            strcat(x,Username);
            strcat(x,"/");
            strcat(x,pMsgID);
            strcat(x,"-deferral.htm");            
            unlink(x);   //��ɾ���ϵ��ļ�

            fp1=fopen(x,"w+b");
     	    if(fp1)
  	    {
  		fprintf(fp1,"<style>p,td{font-size:9pt}</style><br><table border=1 align=center cellpadding=3 cellspacing=0 bordercolorlight=000000 bordercolordark=ffffff bgcolor=ffffff><tr>");
  		fprintf(fp1,"<tr><td>�ռ��˵�ַ</td><td>ʧ������</td><td>ʧ������</td><td width=50>���ʹ���</td></tr>\r\n");
	    }
        }
        else
            strcpy(Message_ID,argv[1]);
        	

        char *selectlist=argv[3];
        int totalmailcount=atoi(argv[4]);
        int totaldeferralcount=atoi(argv[5]);        
        char *DomainFile=argv[6];
        char *DoneFile=argv[7];	
        int DoneFileSize=atoi(argv[8]);	

        FILE * fp;

        //���ļ�ȡ���������ϣ�û����ȡĬ������
        int IsDomainData=0;
        fp=fopen(DomainFile,"r");
        if(fp)
        {  

	    char buffer[255];
	    char *pos;
            cur_domainlist_len=0;
	    other_domainlist_count=totalmailcount;
	    while(fgets(buffer,sizeof(buffer),fp))
            {
                pos=strchr(buffer,'\r');
                if(pos) *pos='\0';
                pos=strchr(buffer,'\t');
		if(pos)
		{
		    *pos='\0';
		    strcpy(cur_domainlist[cur_domainlist_len],buffer);
		    pos++;
		    cur_domainlist_count[cur_domainlist_len]=atoi(pos);
		    other_domainlist_count-=cur_domainlist_count[cur_domainlist_len];

		    cur_domainlist_len++;
		    
		}
            }
            
            fclose(fp);
        
            IsDomainData=1;
            
        }
        else
        {
            //cur_domainlist_len=domainlist_len;            
            cur_domainlist_len=50;            
            int i;
            for(i=0;i<cur_domainlist_len;i++)
            {
                strcpy(cur_domainlist[i],domainlist[i]);
            }
            

	}

        //���ļ�ȡ���ѷ������Email
        char *Dones=(char *)malloc(DoneFileSize+4);
        strcpy(Dones,"\r\n");
        fp=fopen(DoneFile,"r");
        if(fp)
        {  
	    char buffer[256];
	    while(fgets(buffer,sizeof(buffer),fp))
            {
	        strcat(Dones,buffer);
            }
            
            strcat(Dones,"\r\n");
            fclose(fp);
        
        }

	//����
	
	///ȡ��Deferral����
        fp=fopen(Message_ID,"r+b");
        if(!fp)
        {  
    	    //printf("open file error:%s",Message_ID);
    	    //printf("--");
    	    exit(1);
        }
    
	int len = 0L;
     	fseek(fp, 0L, SEEK_END);
     	len = ftell(fp); 
     	fseek(fp, 0L, SEEK_SET);
        Deferral=(char *)malloc(len*2+1);   //ȡ��־��2����
	*Deferral='\0';

        char *Token1="\n\n<";   //�Դ˱���ж��ж���bounce���ʼ���ַ        
        char *Token2=">:\n";   
        int count=0;
        char buf[524288];        //buf 512K
        char *record,*domain,*email,*bounce,*deliveryno;
        char *pos,*pos1,*pos2;
	int i,j,k;


        //��ʼ��ͳ������
    	for(i=0;i<cause_type_len;i++)
    	{
    	    for(j=0;j<domainlist_len;j++)
              bounce_stat_detail[i][j]=0;
    	}

        //while(fgets(buf,sizeof(buf),fp))
        while(!feof(fp))
        {
            fread(buf,sizeof(buf),1,fp);
            record=buf;
            
            char lls[256];
            char buf[8192];
	    char dm[256]="";
            
            strncpy(lls,record,255);
            lls[255]='\0';
            
            while(pos=strstr(record,Token1))
            {
               *pos='\0';
               pos1=record;
	       if(count==0) pos1++;   //��һ���ʼ�ǰ��û��\r\n\r\n
	       record=pos+strlen(Token1);   //record����һ��Token��ʼ               
        
	       //ȡ����������
	       email=pos1;
	       pos1=strchr(pos1,'@');
   	       if(!pos1) continue;
	       //pos1++;
	       pos2=strstr(pos1,Token2);
	       if(!pos2) continue;
	       *pos2='\0';
	       domain=pos1;	       
	       pos1=pos2+strlen(Token2);
	      
	       sprintf(dm,"\r\n%s\r\n",email);
	       if(strstr(Dones,dm)!=NULL)
	       {
	       	     //printf("==%s==<br>\r\n",dm);
	       	     continue;   //������ѵ��ͽ�������ַ���ҵ��������
		}

	       count++;
	       
	       //ȡ�õ���ԭ�򼰷���ͳ�ƣ�
	       //printf("==%d==%s==<br>\r\n",count,domain);
	       dup_analysis(pos1,email);
	        
            }
    
            //�������һ��
            pos1=record;
	    if(count==0) pos1++;   //��һ���ʼ�ǰ��û��\r\n\r\n
	    //ȡ����������
	    email=pos1;
	    pos1=strchr(pos1,'@');
	    if(!pos1) continue;
	    //pos1++;
	    pos2=strstr(pos1,Token2);
	    if(!pos2) continue;
	    *pos2='\0';
	    domain=pos1;	       
	    pos1=pos2+strlen(Token2);
	       
	    sprintf(dm,"\r\n%s\r\n",email);
	    if(strstr(Dones,dm)!=NULL) continue;   //������ѵ��ͽ�������ַ���ҵ��������

	    count++;

	    dup_analysis(pos1,email);	       
        }
        
        count=0;   //reset
        pos=strchr(Deferral,'^');
	while(pos)
	{
            pos++;
            email=pos;
	    while(*pos && *pos!='\1') pos++;
	    *pos='\0';
	    pos++;
	    bounce=pos;            
	    while(*pos && *pos!='\2') pos++;
	    *pos='\0';
	    pos++;
	    deliveryno=pos;            
	    while(*pos && *pos!='\3') pos++;
	    *pos='\0';
            
            pos++;
            pos=strchr(pos,'^');
            
            count++;

	    bounce_analysis(bounce,email,deliveryno);       
	}
	
	//fprintf(fp1,"%s",Deferral);   

        free(Dones);   //�ͷ��ڴ�
	free(Deferral);

        fclose(fp);                
        
	/*
	       //������Ϣ ��ӡ����ԭ��
	       for(i=0;i<cause_len;i++)
	       {	   
	       	            printf("%s--<font color=red>%d</font><br>\r\n",bounce_cause[i],i);
	       	   
	       }
	*/

      
        //�������������ͳ��
   	for(i=0;i<cause_type_len;i++)
	{
	     other_bounce_stat[i]=bounce_stat[i];
	     for(j=0;j<cur_domainlist_len;j++)
	     {
                  other_bounce_stat[i]-=bounce_stat_detail[j][i];
  	     }
        }
        
        //��ӡ������
        
        printf("��<font style='font-size:14.8px' color=red>����ͳ�Ʒ���</font><br><br>\r\n");

        printf("<ul><li>��ʱ����ʧ������������%d<br><br>\r\n",count);
	
	int othercount=count;
	for(k=0;k<cause_type_len;k++)
	{
	     othercount-=bounce_stat[k];
	     printf("<li>%s��%d<br><br>\r\n",bounce_type[k],bounce_stat[k]);
	}
        
	printf("</ul>\r\n");

        printf("\r\n<br>��<font style='font-size:14.8px' color=red>��������ͳ��</font><br><br>\r\n");
        
  	printf("<table border=1 align=center cellpadding=3 cellspacing=0 bordercolorlight=000000 bordercolordark=ffffff bgcolor=ffffff><tr>");
  	printf("<td>��������</td>\r\n");
  	
	for(i=0;i<cause_type_len;i++)
	{
  	     printf("<td>%s</td>\r\n",bounce_type[i]);
	}
	
	printf("<td>ʧ���ܼ�</td>");
	
	//����ʱ����ʧ�ܲ�����ʧ���� 2010 05 20
	//if(IsDomainData) printf("<td>�����ܼ�</td><td>����ʧ����</td>");
	if(IsDomainData) printf("<td>�����ܼ�</td>");

	printf("</tr>");
	
	
	
	//printf("<td>%s</td>\r\n","����ԭ��");
	
	int bounce_totalcount=0;  //ͳ���ܵ�ʧ�ܵ�����
	for(i=0;i<cur_domainlist_len;i++)
	{
	    int domain_bounce_totalcount=0;
	    
	    printf("<tr align=center>");
	    if(IsDomainData)
	        printf("<td align=left>%s</td>",cur_domainlist[i]);
	    else
	    	printf("<td align=left>%s</td>",domainlist[i]);
	    
   	    for(j=0;j<cause_type_len;j++)
	    {
  	         if(bounce_stat_detail[i][j]==0)
   	             printf("<td>%d</td>",bounce_stat_detail[i][j]);
   	         else
   	             printf("<td><font color=blue>%d</font></td>",bounce_stat_detail[i][j]);
   	             
   	        domain_bounce_totalcount+=bounce_stat_detail[i][j];
  	    }
  	    
  	    bounce_totalcount+=domain_bounce_totalcount;
  	    
  	    //��ʾ�����������ܼ�ʧ�������ܼƷ�����	    
   	    printf("<td><font color=red>%d</td>",domain_bounce_totalcount);
   	    //����ʱ����ʧ�ܲ�����ʧ����  2010 05 20
  	    //if(IsDomainData) printf("<td><font color=red>%d</td><td><font color=red>%3.1f%%</td>",cur_domainlist_count[i],((float)(domain_bounce_totalcount)*100)/cur_domainlist_count[i]);
  	    if(IsDomainData) printf("<td><font color=red>%d</td>",cur_domainlist_count[i]);
  	      	    
  	    printf("</tr>");
  	    
	}

		
	//��ʾ�������������ͳ��
	printf("<tr align=center>");
	printf("<td align=left>����</td>");
	
	int domain_bounce_totalcount=0;
   	for(j=0;j<cause_type_len;j++)
	{
  	         if(other_bounce_stat[j]==0)
   	             printf("<td>%d</td>",other_bounce_stat[j]);
   	         else
   	             printf("<td><font color=blue>%d</font></td>",other_bounce_stat[j]);
   	             
   	        domain_bounce_totalcount+=other_bounce_stat[j];
  	}

  	bounce_totalcount+=domain_bounce_totalcount;

  	//��ʾ�������������ܼ�ʧ�������ܼƷ�����	    
   	printf("<td><font color=red>%d</td>",domain_bounce_totalcount);
  	if(IsDomainData)
  	{
   	    //����ʱ����ʧ�ܲ�����ʧ����  2010 05 20
    	    if(other_domainlist_count)
  		//printf("<td><font color=red>%d</td><td><font color=red>%3.1f%%</td>",other_domainlist_count,((float)(domain_bounce_totalcount)*100)/other_domainlist_count);
  		printf("<td><font color=red>%d</td>",other_domainlist_count);
  	    else
  		//printf("<td><font color=red>0</td><td><font color=red>0.0%</td>");
  		printf("<td><font color=red>0</td>");
	}
  	printf("</tr>");

	/////////////////////////////////��ʾ�ܵ�ͳ��
	printf("<tr align=center>");
	printf("<td align=left>�ܼ�</td>");
	    
   	for(j=0;j<cause_type_len;j++)
	{
  	         if(bounce_stat[j]==0)
   	             printf("<td>%d</td>",bounce_stat[j]);
   	         else
   	             printf("<td><font color=blue>%d</font></td>",bounce_stat[j]);
  	}

  	//��ʾ�ܵ��ܼ�ʧ�������ܼƷ�����	    
   	printf("<td><font color=red>%d</td>",bounce_totalcount);
   	//����ʱ����ʧ�ܲ�����ʧ����  2010 05 20
  	//if(IsDomainData) printf("<td><font color=red>%d</td><td><font color=red>%3.1f%%</td>",totalmailcount,((float)(bounce_totalcount)*100)/totalmailcount);
  	if(IsDomainData) printf("<td><font color=red>%d</td>",totalmailcount);

  	printf("</tr>");

  	printf("</table>");
 	       

  	if(fp1)
  	{
  	     fprintf(fp1,"</table>");
  	     fclose(fp1);
	}

        //if(deferrals) delete[] deferrals;
        
    return 0;
}
