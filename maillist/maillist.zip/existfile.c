#include <stdio.h>

int main(int argc, char* argv[])
{
    FILE * fp;
    fp=fopen(argv[1],"r");
    if(fp)
    {
        fclose(fp);
        printf("File Exist\r\n");
        return 1;
    }
    else
    {
        printf("File Not Exist\r\n");
        return 0;
    }
    
}
