#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char* argv[])
{

    if(argc>3) exit(2);

    char *pParam=argv[1];
    char *pValue=argv[2];

    char Message_ID[255]="";        
    
    if(strcmp(pParam,"-c")==0 || strcmp(pParam,"-q")==0)
    {
        
        if(strcmp(pParam,"-c")==0)
            strcpy(Message_ID,"/var/qmail/control/concurrencyremote");
	else
            strcpy(Message_ID,"/var/qmail/control/queuelifetime");	

        FILE * fp;
        fp=fopen(Message_ID,"w"); 
	fwrite(pValue,strlen(pValue),1,fp);
        fclose(fp);
        
    }
    else if(strcmp(pParam,"-d")==0)   //�Զ���ʱ��������
    {
    	        
        strcpy(Message_ID,"reboot");	

        FILE * fp;
        fp=fopen(Message_ID,"w"); 
	fwrite(pValue,strlen(pValue),1,fp);
        fclose(fp);
    }
    else if(strcmp(pParam,"-s")==0)
    {    	        
        execl("/usr/sbin/qmail","restart");
    }
    else if(strcmp(pParam,"-r")==0)
    {    	        
        execl("reboot","");
    }
    else
        exit(2);
      

    return 0;
}
