#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "/usr/local/mysql/include/mysql.h"

#include "bounce.h"

/*
//������Ҫ���·�ʽ��
gcc -o deferralstat1 deferralstat1.c -L/usr/local/mysql/lib -lmysqlclient -lnsl -lm -lz
*/


char *stristr(const char *String, const char *Pattern)
{
      char *pptr, *sptr, *start;
      unsigned int  slen, plen;

      for (start = (char *)String,
           pptr  = (char *)Pattern,
           slen  = strlen(String),
           plen  = strlen(Pattern);

           /* while string length not shorter than pattern length */

           slen >= plen;

           start++, slen--)
      {
            /* find start of pattern in string */
            while (toupper(*start) != toupper(*Pattern))
            {
                  start++;
                  slen--;

                  /* if pattern longer than string */

                  if (slen < plen)
                        return(NULL);
            }

            sptr = start;
            pptr = (char *)Pattern;

            while (toupper(*sptr) == toupper(*pptr))
            {
                  sptr++;
                  pptr++;

                  /* if end of pattern then pattern was found */

                  if ('\0' == *pptr)
                        return (start);
            }
      }
      return(NULL);
}



FILE * fp1=NULL;

void bounce_analysis(char *bounce,char *email,char *DeliveryNo)
{
	       
	    char *pos2,*domain;
	    int i,j,k;
	       
	    domain=strchr(email,'@');
	    if(!domain) return;

	       //ȡ�õ���ԭ�򼰷���ͳ�ƣ�
	       for(i=0;i<cause_len;i++)
	       {
	       	   
	       	   if(pos2=strchr(bounce_cause[i],'|'))  //����| 
	       	   {
	       	       char sign1[64],sign2[64];
	       	       strncpy(sign1,bounce_cause[i],pos2-bounce_cause[i]-1);
	       	       sign1[pos2-bounce_cause[i]-1]='\0';
	       	       strcpy(sign2,pos2+1);
       	       
	       	       
	       	       if(strstr(bounce,sign1) && strstr(bounce,sign2))
	       	       {
	       	           break;
	       	       }
	       	   }
	       	   else
	       	   {
	       	       if(strstr(bounce,bounce_cause[i]))
	       	       {
	       	            //printf("%s--<font color=red>%d</font><br>\r\n",bounce,i);
	       	       	    break;
	       	       }
	       	   }
	       	   
	       }
	       
	       //����ԭ�����ͳ��
	       for(j=0;j<cause_type_len;j++)
	       {
	       	  
	       	  //printf("%d<br>\r\n",i);
	       	  if(i<=bounce_type_num[j])
	       	  {
	       	     bounce_stat[j]++;
	       	     //printf("%d==%s<br>\r\n",bounce_stat[j],domain);

	       	     //������������ͳ��
	       	     //printf("%d==<br>\r\n",cur_domainlist_len);

	       	     for(k=0;k<cur_domainlist_len;k++)
	       	     {
	       	        if(strcmp(domain,cur_domainlist[k])==0)
	       	        {
	       	          bounce_stat_detail[k][j]++;
	       	          //printf("%s-%d-%d-%d<br>\r\n",domain,bounce_stat_detail[k][j],k,j);

	       	          break;
	       	        } 
	       	  	
	       	     }

	       	      break;
	       	  }
	       	  
	       	  
	       }
 
}
//////////////////////////////////////////////////

int main(int argc, char* argv[])
{

    if(argc>7) exit(2);
    	
        char *Message_ID=argv[1];   //��ʱδ��

        char *Username=argv[2];

        char *selectlist=argv[3];
        int totalmailcount=atoi(argv[4]);
        int totaldeferralcount=atoi(argv[5]);        
        char *DomainFile=argv[6];


        FILE * fp;

        //���ļ�ȡ���������ϣ�û����ȡĬ������
        int IsDomainData=0;
        fp=fopen(DomainFile,"r");
        if(fp)
        {  

	    char buffer[255];
	    char *pos;
            cur_domainlist_len=0;
	    other_domainlist_count=totalmailcount;
	    while(fgets(buffer,sizeof(buffer),fp))
            {
                pos=strchr(buffer,'\r');
                if(pos) *pos='\0';
                pos=strchr(buffer,'\t');
		if(pos)
		{
		    *pos='\0';
		    strcpy(cur_domainlist[cur_domainlist_len],buffer);
		    pos++;
		    cur_domainlist_count[cur_domainlist_len]=atoi(pos);
		    other_domainlist_count-=cur_domainlist_count[cur_domainlist_len];

		    cur_domainlist_len++;
		    
		}
            }
            
            fclose(fp);
        
            IsDomainData=1;
            
        }
        else
        {
            //cur_domainlist_len=domainlist_len;            
            cur_domainlist_len=50;            
            int i;
            for(i=0;i<cur_domainlist_len;i++)
            {
                strcpy(cur_domainlist[i],domainlist[i]);
            }
            

	}

        int count=0;
        char *domain,*email,*bounce,*deliveryno;
        char *pos;
	int i,j,k;


        //��ʼ��ͳ������
    	for(i=0;i<cause_type_len;i++)
    	{
    	    for(j=0;j<domainlist_len;j++)
              bounce_stat_detail[i][j]=0;
    	}
        

	//��ʼͨ����ѯmysql����
    	MYSQL *sql_p;
    	MYSQL_RES *result_p;
    	MYSQL_ROW row_p;
    	int res;

    	sql_p=mysql_init(NULL);
    	if(sql_p==NULL)
    	{
            printf("Init mysql error!\n");
            exit(1);
        }

        sql_p=mysql_real_connect(sql_p,"localhost","root","qazwsx","ezmlm",0,NULL,0);
        if(!sql_p)
        {
            fprintf(stderr,"%d:%s\n",mysql_errno(sql_p),mysql_error(sql_p));
            exit(1);
        }

   	char sql[512]="";
    	sprintf(sql,"select address,bounce,delcount from %s where result='D'",selectlist);
        res=mysql_query(sql_p,sql);
        if(res)
        {
            printf("Select error:%s!\n",sql);
            exit(1);
        }
    
	result_p=mysql_store_result(sql_p);
        if(!result_p)
        {
            printf("Select error!\n");
            exit(1);
        }
      
   	//num=(in)mysql_num_rows(res);
   	//printf("query over and row num is%d\n",num);
  	
        count=0;   //reset
	while((row_p=mysql_fetch_row(result_p)))
        {
    	    //for(t=0;t<mysql_num_fields(result_p);t++)
            email=row_p[0];
            bounce=row_p[1];
            deliveryno=row_p[2];     	    

            count++;
	    bounce_analysis(bounce,email,deliveryno);
        }

    	mysql_free_result(result_p);
        
        //��ѯ1����¼
        /*
        result_p=mysql_use_result(sql_p);
    	if(!result_p)
    	{
            printf("mysql_use error!\n");
            exit(1);
    	}

    	row_p=mysql_fetch_rows(result_p);
    	printf("%s\n",row_p[0]);
    	*/
    	
    	mysql_close(sql_p);


        
	/*
	       //������Ϣ ��ӡ����ԭ��
	       for(i=0;i<cause_len;i++)
	       {	   
	       	            printf("%s--<font color=red>%d</font><br>\r\n",bounce_cause[i],i);
	       	   
	       }
	*/

      
        //�������������ͳ��
   	for(i=0;i<cause_type_len;i++)
	{
	     other_bounce_stat[i]=bounce_stat[i];
	     for(j=0;j<cur_domainlist_len;j++)
	     {
                  other_bounce_stat[i]-=bounce_stat_detail[j][i];
  	     }
        }
        
        //��ӡ������
        
        printf("��<font style='font-size:14.8px' color=red>����ͳ�Ʒ���</font><br><br>\r\n");

        printf("<ul><li>��ʱ����ʧ������������%d<br><br>\r\n",count);
	
	int othercount=count;
	for(k=0;k<cause_type_len;k++)
	{
	     othercount-=bounce_stat[k];
	     printf("<li>%s��%d<br><br>\r\n",bounce_type[k],bounce_stat[k]);
	}
        
	printf("</ul>\r\n");

        printf("\r\n<br>��<font style='font-size:14.8px' color=red>��������ͳ��</font><br><br>\r\n");
        
  	printf("<table border=1 align=center cellpadding=3 cellspacing=0 bordercolorlight=000000 bordercolordark=ffffff bgcolor=ffffff><tr>");
  	printf("<td>��������</td>\r\n");
  	
	for(i=0;i<cause_type_len;i++)
	{
  	     printf("<td>%s</td>\r\n",bounce_type[i]);
	}
	
	printf("<td>ʧ���ܼ�</td>");
	
	//����ʱ����ʧ�ܲ�����ʧ���� 2010 05 20
	//if(IsDomainData) printf("<td>�����ܼ�</td><td>����ʧ����</td>");
	if(IsDomainData) printf("<td>�����ܼ�</td>");

	printf("</tr>");
	
	
	
	//printf("<td>%s</td>\r\n","����ԭ��");
	
	int bounce_totalcount=0;  //ͳ���ܵ�ʧ�ܵ�����
	for(i=0;i<cur_domainlist_len;i++)
	{
	    int domain_bounce_totalcount=0;
	    
	    printf("<tr align=center>");
	    if(IsDomainData)
	        printf("<td align=left>%s</td>",cur_domainlist[i]);
	    else
	    	printf("<td align=left>%s</td>",domainlist[i]);
	    
   	    for(j=0;j<cause_type_len;j++)
	    {
  	         if(bounce_stat_detail[i][j]==0)
   	             printf("<td>%d</td>",bounce_stat_detail[i][j]);
   	         else
   	             printf("<td><font color=blue>%d</font></td>",bounce_stat_detail[i][j]);
   	             
   	        domain_bounce_totalcount+=bounce_stat_detail[i][j];
  	    }
  	    
  	    bounce_totalcount+=domain_bounce_totalcount;
  	    
  	    //��ʾ�����������ܼ�ʧ�������ܼƷ�����	    
   	    printf("<td><font color=red>%d</td>",domain_bounce_totalcount);
   	    //����ʱ����ʧ�ܲ�����ʧ����  2010 05 20
  	    //if(IsDomainData) printf("<td><font color=red>%d</td><td><font color=red>%3.1f%%</td>",cur_domainlist_count[i],((float)(domain_bounce_totalcount)*100)/cur_domainlist_count[i]);
  	    if(IsDomainData) printf("<td><font color=red>%d</td>",cur_domainlist_count[i]);
  	      	    
  	    printf("</tr>");
  	    
	}

		
	//��ʾ�������������ͳ��
	printf("<tr align=center>");
	printf("<td align=left>����</td>");
	
	int domain_bounce_totalcount=0;
   	for(j=0;j<cause_type_len;j++)
	{
  	         if(other_bounce_stat[j]==0)
   	             printf("<td>%d</td>",other_bounce_stat[j]);
   	         else
   	             printf("<td><font color=blue>%d</font></td>",other_bounce_stat[j]);
   	             
   	        domain_bounce_totalcount+=other_bounce_stat[j];
  	}

  	bounce_totalcount+=domain_bounce_totalcount;

  	//��ʾ�������������ܼ�ʧ�������ܼƷ�����	    
   	printf("<td><font color=red>%d</td>",domain_bounce_totalcount);
  	if(IsDomainData)
  	{
   	    //����ʱ����ʧ�ܲ�����ʧ����  2010 05 20
    	    if(other_domainlist_count)
  		//printf("<td><font color=red>%d</td><td><font color=red>%3.1f%%</td>",other_domainlist_count,((float)(domain_bounce_totalcount)*100)/other_domainlist_count);
  		printf("<td><font color=red>%d</td>",other_domainlist_count);
  	    else
  		//printf("<td><font color=red>0</td><td><font color=red>0.0%</td>");
  		printf("<td><font color=red>0</td>");
	}
  	printf("</tr>");

	/////////////////////////////////��ʾ�ܵ�ͳ��
	printf("<tr align=center>");
	printf("<td align=left>�ܼ�</td>");
	    
   	for(j=0;j<cause_type_len;j++)
	{
  	         if(bounce_stat[j]==0)
   	             printf("<td>%d</td>",bounce_stat[j]);
   	         else
   	             printf("<td><font color=blue>%d</font></td>",bounce_stat[j]);
  	}

  	//��ʾ�ܵ��ܼ�ʧ�������ܼƷ�����	    
   	printf("<td><font color=red>%d</td>",bounce_totalcount);
   	//����ʱ����ʧ�ܲ�����ʧ����  2010 05 20
  	//if(IsDomainData) printf("<td><font color=red>%d</td><td><font color=red>%3.1f%%</td>",totalmailcount,((float)(bounce_totalcount)*100)/totalmailcount);
  	if(IsDomainData) printf("<td><font color=red>%d</td>",totalmailcount);

  	printf("</tr>");

  	printf("</table>");
 	       
    return 0;
}
