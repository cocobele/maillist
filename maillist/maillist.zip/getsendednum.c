#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[])
{

    if(argc>4) exit(2);

    if(strcmp(argv[1],"-S")==0)
    {
        char Message_ID[255]="";
        //�����ʼΪ/��˵����ȫ·���������·����
        if(argv[2][0]!='/') strcpy(Message_ID,"/var/qmail/queue/remote/");
        strcat(Message_ID,argv[2]);

        FILE * fp;
        fp=fopen(Message_ID,"r+b");
        if(!fp)
        {  
    	    printf("open file error:%s",Message_ID);
    	    //printf("--");
    	    exit(1);
        }
    
        int chr,prechr='#';
        //int len=0;  //�ֽ���
        int totalcount=0,count=0,lastcount=0;  //��¼δ����
        //while ((chr = fgetc(fp)) != EOF)  //ֻ�ʺ��ı���ʽ
        while(!feof(fp)) 
        {
            chr = fgetc(fp);
            if(chr== 'D')
            {
                if(prechr=='\0' || prechr=='#')   //#��Ե�һ��D����
                {
		    count++;
		    lastcount=totalcount+1;
		}
            }
            else if(chr== '\0')
                totalcount++;


            //len++;
            prechr=chr;
        
        }

        fclose(fp);
        
        //printf("%d == %d",len,count);    
        printf("%d:%d:%d",count,lastcount,totalcount);
    }
    else if(strcmp(argv[1],"-F")==0)   //��remote��������з�����ϵ��ʼ���ַ
    {
        char Message_ID[255]="";
        //�����ʼΪ/��˵����ȫ·���������·����
        if(argv[2][0]!='/') strcpy(Message_ID,"/var/qmail/queue/remote/");
        strcat(Message_ID,argv[2]);

        FILE * fp,*fp1;
        fp=fopen(Message_ID,"r+b");
        if(!fp)
        {  
    	    printf("open file error:%s",Message_ID);
    	    //printf("--");
    	    exit(1);
        }
    
    	char *DoneFile=argv[3];
        fp1=fopen(DoneFile,"w+b");
        if(!fp1)
        {  
    	    printf("open file error:%s",DoneFile);
    	    //printf("--");
    	    exit(1);
        }

        char email[256]="";
        int i=0;
        int IsDone=0;
        int chr,prechr='#';
        int totalcount=0,count=0,lastcount=0;  //��¼δ����
        //while ((chr = fgetc(fp)) != EOF)  //ֻ�ʺ��ı���ʽ
        while(!feof(fp)) 
        {
            chr = fgetc(fp);
            if(chr== 'D')
            {
                if(prechr=='\0' || prechr=='#')   //#��Ե�һ��D����
                {
		    count++;
		    lastcount=totalcount+1;
		}
		IsDone=1;
		i=0;   //reset
            }
            else if(chr== '\0')
	    {
	    	email[i]=chr;
                if(IsDone==1)
                {
                    totalcount++;
                    //printf("%s\r\n",email);
                    if(fp1)  fprintf(fp1,"%s\r\n",email);           //д��L�ļ�����
		}
		IsDone=0;
	    }
            else
            {
		if(IsDone==1) email[i++]=chr;
	    }
	    
            //len++;
            prechr=chr;
        
        }

        fclose(fp);
        
        fclose(fp1);
        
        printf("%d",totalcount);
    }
    else if(strcmp(argv[1],"-B")==0 || strcmp(argv[1],"-A")==0)  //A �ɹ� B ʧ��
    {

        char Message_ID[255]="";
        //�����ʼΪ/��˵����ȫ·���������·����
        if(argv[2][0]!='/')
        {
            char *pMsgID=strchr(argv[2],'/');
            if(!pMsgID)
                pMsgID=argv[2];
            else
                pMsgID++;
        
            if(strcmp(argv[1],"-B")==0)
                strcpy(Message_ID,"/var/qmail/queue/bounce/");
            else
                strcpy(Message_ID,"/var/qmail/queue/success/");

            strcat(Message_ID,pMsgID);
        }
        else
            strcpy(Message_ID,argv[2]);            
        
        FILE * fp;
        fp=fopen(Message_ID,"r+b");
        if(!fp)
        {  
    	    printf("open file error:%s",Message_ID);
    	    //printf("--");
    	    exit(1);
        }
    
        char Token[8]=">:\n";   //�Դ˱���ж��ж���bounce���ʼ���ַ        
        int count=0;
        int chr,prechr='\0',oldprechr='\0';

        while(!feof(fp)) 
        {
            chr = fgetc(fp);
            if(chr== '\n')
            {
                if(oldprechr=='>' && prechr==':')
		    count++;
            }

            oldprechr=prechr;
            prechr=chr;
            
        }

        fclose(fp);
        
        printf("%d",count);

    }
    else if(strcmp(argv[1],"-D")==0 || strcmp(argv[1],"-C")==0)   //�����Ŀ�������ʼ����ļ���
    {
    	
    	char *BounceFile=argv[3];
        char Message_ID[255]="";
        //�����ʼΪ/��˵����ȫ·���������·����
        if(argv[2][0]!='/')
        {
            char *pMsgID=strchr(argv[2],'/');
            if(!pMsgID)
                pMsgID=argv[2];
            else
                pMsgID++;
        
            if(strcmp(argv[1],"-D")==0)
                strcpy(Message_ID,"/var/qmail/queue/bounce/");
            else
                strcpy(Message_ID,"/var/qmail/queue/success/");

            strcat(Message_ID,pMsgID);
        }
        else
            strcpy(Message_ID,argv[2]);
        
	///ȡ��Bounce����
        FILE * fp,*fp1;
        fp=fopen(Message_ID,"r+b");
        if(!fp)
        {  
    	    printf("open file error:%s",Message_ID);
    	    //printf("--");
    	    exit(1);
        }
    
        fp1=fopen(BounceFile,"w+b");

        char *Token1="\n\n<";   //�Դ˱���ж��ж���bounce���ʼ���ַ        
        char *Token2=">:\n";   
        int count=0;
        char buf[524288];        //buf 512K
        char *record,*domain;
        char *pos,*pos1,*pos2;
	int i,j,k;


        //while(fgets(buf,sizeof(buf),fp))
        while(!feof(fp))
        {
            fread(buf,sizeof(buf),1,fp);
            record=buf;
            
            char lls[256];
            
            strncpy(lls,record,255);
            lls[255]='\0';
            
            while(pos=strstr(record,Token1))
            {
               *pos='\0';
               pos1=record;
	       if(count==0) pos1++;   //��һ���ʼ�ǰ��û��\r\n\r\n
	       record=pos+strlen(Token1);   //record����һ��Token��ʼ               
        
               count++;

	       pos2=strstr(pos1,Token2);
	       if(!pos2) continue;
	       *pos2='\0';
	       domain=pos1;	       
	       pos1=pos2+strlen(Token2);
	       
	       pos2=strchr(domain,'@');
   	       if(!pos2) continue;

	       
              //д��L�ļ�����
              if(fp1) fprintf(fp1,"%s\r\n",domain);
	        
            }
    
            
            pos1=record;
	    if(count==0) pos1+=2;   //��һ���ʼ�ǰ��û��\r\n\r\n
	    pos2=strstr(pos1,Token2);
	    if(!pos2) continue;
	    *pos2='\0';
	    domain=pos1;	       
	    pos1=pos2+strlen(Token2);
	    count++;

	    pos1=strchr(domain,'@');
	    if(!pos1) continue;
	    	       
            //д��L�ļ�����
            if(fp1) fprintf(fp1,"%s\r\n",domain);
        }

        fclose(fp);
        
        if(fp1) fclose(fp1);
        
        //printf("%d",count);

    }
    else
        exit(2);
      

    return 0;
}
