#include <sys/types.h>
#include <unistd.h>

#include <stdlib.h>

#include <stdio.h>
#include <string.h>

#include <sys/ioctl.h>
#include <fcntl.h>
#include <linux/hdreg.h>
#include <errno.h>

//////////�򻯽ṹ����ʹ�����к�
//#include <stdio.h>

#ifndef byte
#define byte unsigned char
#endif
#ifndef WORD
#define WORD unsigned short
#endif
#ifndef DWORD
#define DWORD long
#endif
#ifndef LOWORD
#define LOWORD(l)           ((WORD)(l))
#endif
#ifndef HIWORD
#define HIWORD(l)           ((WORD)(((DWORD)(l) >> 16) & 0xFFFF))
#endif
#ifndef LOBYTE
#define LOBYTE(w)           ((UBYTE)(w))
#endif
#ifndef HIBYTE
#define HIBYTE(w)           ((UBYTE)(((WORD)(w) >> 8) & 0xFF))
#endif

//typedef   unsigned char byte; 
//typedef   short Word; 
struct {
	WORD CheckValue;
	WORD Expiration;
        int SerialNumber;
} PCode;
//typedef long T128Bit[4];
static const WORD SerialCheckCode = 0x3c69;

//---------------------------------------------------------------------------
int HexToInt(char *Hex_Num)
{
     char chr;
     int Oct_Num=0,mi=1,digit;
     int len=strlen(Hex_Num)-1;
     int i;
     for(i=0;Hex_Num[i];i++)
     {
         chr=Hex_Num[len-i];
         if(chr>=48 && chr <=57)
             digit=chr-48;
         else if(chr >= 'A' && chr <= 'F')
             digit=chr-65+10;
         else if(chr >= 'a' && chr <= 'f')
             digit=chr-97+10;
         else
             return -1;

         Oct_Num+=digit*mi;
         mi*=16;
     }

     return Oct_Num;
}
//---------------------------------------------------------------------------
char *IntToHex(int Num)   //gcc��û�иú�����Ҫ�Լ���
{
    int A=Num/16;
    int B=Num%16;
    
    char Hex[3]="";
    if(A<=9)
        Hex[0]=A+48;
    else
        Hex[0]=A-10+65;


    if(B<=9)
        Hex[1]=B+48;
    else
        Hex[1]=B-10+65;
    
    Hex[2]='\0';
    
    //printf("==%s==\n",Hex);
    return Hex;   
}
//---------------------------------------------------------------------------
//void MixBlock(const long * Matrix,TCode Block,bool Encrypt)
void MixBlock(const long *Matrix,_Bool Encrypt)
{

  //TKey Byte[16]  ת��Ϊlong[4]
  //Key E58F84D692C9A4D81AFA6F8DABFCDFB4
  //Serial  0
  //Code  6DB5F7E0E6D154FA


  long CKeyBox[2][4][3]={
                        {{0, 3, 1}, {2, 1, 3}, {1, 0, 2}, {3, 2, 0}},
                        {{3, 2, 0}, {1, 0, 2}, {2, 1, 3}, {0, 3, 1}}
                     };
  long Blocks[2];
  //Blocks[0]=Block.CheckValue + Block.Expiration *65536;  //693C889B Ӧ���� 9B88 *65536 + 3c69
  //Blocks[1]=Block.SerialNumber;
  Blocks[0]=PCode.CheckValue + PCode.Expiration *65536;  //693C889B Ӧ���� 9B88 *65536 + 3c69
  Blocks[1]=PCode.SerialNumber;
  long Work;
  long Right;
  long Left;
  long R;
  long AA, BB;
  long CC, DD;

  Right = Blocks[0];
  Left = Blocks[1];

  for( R=0;R<=3;R++)
  {
    //transform the right side
    AA = Right;
    BB = Matrix[CKeyBox[Encrypt][R][0]];   //Matrix[3]  ABFCDFB4
    CC = Matrix[CKeyBox[Encrypt][R][1]];   //Matrix[2]  1AFA6F8D
    DD = Matrix[CKeyBox[Encrypt][R][2]];   //Matrix[0]  E58F84D6


    //commented code does not affect results - removed for speed
    AA = AA + DD; DD = DD + AA; AA = AA ^ ((unsigned long)AA >> 7);
    BB = BB + AA; AA = AA + BB; BB = BB ^ ((unsigned long)BB << 13);
    CC = CC + BB; BB = BB + CC; CC = CC ^ ((unsigned long)CC >> 17);
    DD = DD + CC; CC = CC + DD; DD = DD ^ ((unsigned long)DD << 9);
    AA = AA + DD; DD = DD + AA; AA = AA ^ ((unsigned long)AA >> 3);
    BB = BB + AA; //AA := AA + BB;}
    BB = BB ^ ((unsigned long)BB << 7);
    CC = CC + BB; //BB := BB + CC;}
    CC = CC ^ ((unsigned long)DD >> 15);
    DD = DD + CC; //CC := CC + DD;}
    DD = DD ^ ((unsigned long)DD << 11);

    Work = Left ^ DD;
    Left = Right;
    Right = Work;

  }

  Blocks[0] = Left;
  Blocks[1] = Right;


  //PCode.CheckValue=LOWORD(Blocks[0]);
  //PCode.Expiration=HIWORD(Blocks[0]);
  unsigned int X=(unsigned int)Blocks[0];
  PCode.CheckValue=X%65536;
  PCode.Expiration=X/65536;
  PCode.SerialNumber=Blocks[1];

  //printf("%d==%d==%d==%d\n",X,PCode.CheckValue,PCode.Expiration,PCode.SerialNumber);
}
//---------------------------------------------------------------------------
/*
Word ShrinkDate(TDateTime D)
{
    
    int BaseDate = floor(EncodeDate(1996, 1, 1));
    if(floor(D) == 0 || floor(D)-BaseDate>High(Word))
        return 0;
    else
        return floor(D) - BaseDate;
}
*/
//---------------------------------------------------------------------------
//void __fastcall InitSerialNumberCode(TKey Key;long Serial;TDateTime Expires;TCode Code)
//void InitSerialNumberCode(const long * Key, int Serial, TCode &Code)
void InitSerialNumberCode(const long * Key, int Serial)
{
    PCode.CheckValue = SerialCheckCode;
    //Code.Expiration = ShrinkDate(Expires);  //���ڲ���Expire��һ�������
    PCode.Expiration = 0;
    PCode.SerialNumber = Serial;
    //MixBlock(Key, Code,true);
    MixBlock(Key,1);
}
//---------------------------------------------------------------------------
char * BufferToHex(unsigned int BufSize)
{

    byte Bytes[8];
    Bytes[0]=(byte)(PCode.CheckValue);
    Bytes[1]=(byte)(PCode.CheckValue>>8);
    Bytes[2]=(byte)(PCode.Expiration);
    Bytes[3]=(byte)(PCode.Expiration>>8);
    Bytes[4]=(byte)(PCode.SerialNumber);
    Bytes[5]=(byte)(PCode.SerialNumber>>8);
    Bytes[6]=(byte)(PCode.SerialNumber>>16);
    Bytes[7]=(byte)(PCode.SerialNumber>>24);

    int i;
    char Result[32]= "";
    for(i= 0;i<BufSize;i++)
    {
       //Result = Result + IntToHex(Bytes[i], 2);
       char Val[3];
       strcpy(Val,IntToHex(Bytes[i]));
       Result[2*i]=Val[0];
       Result[2*i+1]=Val[1];
    }
    Result[2*BufSize]='\0';
    
    //ע��ǰ��λ����Ϊ 0 -28����Ҫȥ��  2012 03 10
    //printf("==%s==\n",Result+2);
    if(*Result)
        return Result;
    else
        return Result+2;
}
//---------------------------------------------------------------------------
void gencode(char *DiskID,char *szKey,char *RegSN)
{

    int i; //����ŵ�for�⣬���򲻷���C99ģʽ
    char Key[4][9];
    for(i=0;szKey[i];i++)
    {
        Key[i/8][i%8]=szKey[i];
    }
    Key[0][8]='\0';
    Key[1][8]='\0';
    Key[2][8]='\0';
    Key[3][8]='\0';
    char  Val[9]="";
    long K[4];
    for(i=0;i<4;i++)
    {
      //ע���˴�Ӧ���ǰ���λ��ǰ����λ�ں���㣬
      //Val=Key[i].SubString(7,2)+Key[i].SubString(5,2)+Key[i].SubString(3,2)+Key[i].SubString(1,2);
      Val[0]=Key[i][6];
      Val[1]=Key[i][7];
      Val[2]=Key[i][4];
      Val[3]=Key[i][5];
      Val[4]=Key[i][2];
      Val[5]=Key[i][3];
      Val[6]=Key[i][0];
      Val[7]=Key[i][1];
      Val[8]='\0';
      //printf("Val:%s\n",Val);      
      K[i]=HexToInt(Val);
    }

    //InitSerialNumberCode(K, StrToIntDef(SerialNumberEd->Text, 0));
    //printf("=%s=%d==\n",DiskID,atoi(DiskID));
    InitSerialNumberCode(K, atoi(DiskID));

    //char RegSN[32]="";
    strcpy(RegSN,BufferToHex(sizeof(PCode)));
    
    //printf("RegSN:%s\n",RegSN);
    //printf("%s",RegSN);
}
//---------------------------------------------------------------------------
int getregsn(char* DiskID,char *SN)
{
	
    int TypeNo=0;    //Ĭ����webspider�����������

   
    //{E58F84D6,E58F84D6,1AFA6F8D,ABFCDFB4};
    //AnsiString Key[4]={"E58F84D6","92C9A4D8","1AFA6F8D","ABFCDFB4"};
    //AnsiString Val;
    //char Key[33]={"E58F84D692C9A4D81AFA6F8DABFCDFB4"};   //������
    char Key[6][33];
    /*
     //ֱ�Ӹ�ֵ����ȫ����ȡ���η�ʽ
    strcpy(Key[0],"FDC376E838CD309AC37ABDCE628C473A");  //webcatalog_brief;
    strcpy(Key[1],"289EA639ADF1809331F81D68200D4EF2");  //webcasting;
    strcpy(Key[2],"AFA5F878243172973E5655B15F9C278D");  //webcollecting;
    strcpy(Key[3],"FF5E3E9F4FC933BED1E90B59F54F2075");  //minglu;
    strcpy(Key[4],"9E0A43EE288926826DECC9C2856DDB87");  //maillist;
    strcpy(Key[5],"44577B649667F5ECD233F1F40FB9C5CC");  //letter;
    */

    //TKey CKey1 = {0xD4,0x45,0x25,0x51,0xA0,0x22,0x01,0x1D,0x1C,0xFA,0xCE,0x7F,0x1F,0x5D,0x08,0xE1};
    //TKey CKey2 = {0xE1,0xB6,0xDA,0x33,0x39,0xDF,0xF5,0xA9,0x24,0xAF,0xD2,0x4D,0x7C,0x76,0x00,0xA0};

    Key[0][0]='D';  // "289EA639ADF1809331F81D68200D4EF2");  //webspider;
    Key[0][1]='4';
    Key[0][2]='4';
    Key[0][3]='5';
    Key[0][4]='2';
    Key[0][5]='5';
    Key[0][6]='5';
    Key[0][7]='1';
    Key[0][8]='A';
    Key[0][9]='0';
    Key[0][10]='2';
    Key[0][11]='2';
    Key[0][12]='0';
    Key[0][13]='1';
    Key[0][14]='1';
    Key[0][15]='D';
    Key[0][16]='1';
    Key[0][17]='C';
    Key[0][18]='F';
    Key[0][19]='A';
    Key[0][20]='C';
    Key[0][21]='E';
    Key[0][22]='7';
    Key[0][23]='F';
    Key[0][24]='1';
    Key[0][25]='F';
    Key[0][26]='5';
    Key[0][27]='D';
    Key[0][28]='0';
    Key[0][29]='8';
    Key[0][30]='E';
    Key[0][31]='1';
    Key[0][32]='\0';

    Key[1][0]='E';   //"FDC376E838CD309AC37ABDCE628C473A");  //webspider_brief;
    Key[1][1]='1';
    Key[1][2]='B';
    Key[1][3]='6';
    Key[1][4]='D';
    Key[1][5]='A';
    Key[1][6]='3';
    Key[1][7]='3';
    Key[1][8]='3';
    Key[1][9]='9';
    Key[1][10]='D';
    Key[1][11]='F';
    Key[1][12]='F';
    Key[1][13]='5';
    Key[1][14]='A';
    Key[1][15]='9';
    Key[1][16]='2';
    Key[1][17]='4';
    Key[1][18]='A';
    Key[1][19]='F';
    Key[1][20]='D';
    Key[1][21]='2';
    Key[1][22]='4';
    Key[1][23]='D';
    Key[1][24]='7';
    Key[1][25]='C';
    Key[1][26]='7';
    Key[1][27]='6';
    Key[1][28]='0';
    Key[1][29]='0';
    Key[1][30]='A';
    Key[1][31]='0';
    Key[1][32]='\0';

   /*
    Key[2][0]='A';   //"AFA5F878243172973E5655B15F9C278D");  //webcollecting;
    Key[2][1]='F';
    Key[2][2]='A';
    Key[2][3]='5';
    Key[2][4]='F';
    Key[2][5]='8';
    Key[2][6]='7';
    Key[2][7]='8';
    Key[2][8]='2';
    Key[2][9]='4';
    Key[2][10]='3';
    Key[2][11]='1';
    Key[2][12]='7';
    Key[2][13]='2';
    Key[2][14]='9';
    Key[2][15]='7';
    Key[2][16]='3';
    Key[2][17]='E';
    Key[2][18]='5';
    Key[2][19]='6';
    Key[2][20]='5';
    Key[2][21]='5';
    Key[2][22]='B';
    Key[2][23]='1';
    Key[2][24]='5';
    Key[2][25]='F';
    Key[2][26]='9';
    Key[2][27]='C';
    Key[2][28]='2';
    Key[2][29]='7';
    Key[2][30]='8';
    Key[2][31]='D';
    Key[2][32]='\0';


    Key[3][0]='F';   //"FF5E3E9F4FC933BED1E90B59F54F2075");  //minglu;
    Key[3][1]='F';
    Key[3][2]='5';
    Key[3][3]='E';
    Key[3][4]='3';
    Key[3][5]='E';
    Key[3][6]='9';
    Key[3][7]='F';
    Key[3][8]='4';
    Key[3][9]='F';
    Key[3][10]='C';
    Key[3][11]='9';
    Key[3][12]='3';
    Key[3][13]='3';
    Key[3][14]='B';
    Key[3][15]='E';
    Key[3][16]='D';
    Key[3][17]='1';
    Key[3][18]='E';
    Key[3][19]='9';
    Key[3][20]='0';
    Key[3][21]='B';
    Key[3][22]='5';
    Key[3][23]='9';
    Key[3][24]='F';
    Key[3][25]='5';
    Key[3][26]='4';
    Key[3][27]='F';
    Key[3][28]='2';
    Key[3][29]='0';
    Key[3][30]='7';
    Key[3][31]='5';
    Key[3][32]='\0';

    Key[4][0]='9';   //"9E0A43EE288926826DECC9C2856DDB87");  //maillist;
    Key[4][1]='E';
    Key[4][2]='0';
    Key[4][3]='A';
    Key[4][4]='4';
    Key[4][5]='3';
    Key[4][6]='E';
    Key[4][7]='E';
    Key[4][8]='2';
    Key[4][9]='8';
    Key[4][10]='8';
    Key[4][11]='9';
    Key[4][12]='2';
    Key[4][13]='6';
    Key[4][14]='8';
    Key[4][15]='2';
    Key[4][16]='6';
    Key[4][17]='D';
    Key[4][18]='E';
    Key[4][19]='C';
    Key[4][20]='C';
    Key[4][21]='9';
    Key[4][22]='C';
    Key[4][23]='2';
    Key[4][24]='8';
    Key[4][25]='5';
    Key[4][26]='6';
    Key[4][27]='D';
    Key[4][28]='D';
    Key[4][29]='B';
    Key[4][30]='8';
    Key[4][31]='7';
    Key[4][32]='\0';



    Key[5][0]='4';   //"44577B649667F5ECD233F1F40FB9C5CC");  //letter;
    Key[5][1]='4';
    Key[5][2]='5';
    Key[5][3]='7';
    Key[5][4]='7';
    Key[5][5]='B';
    Key[5][6]='6';
    Key[5][7]='4';
    Key[5][8]='9';
    Key[5][9]='6';
    Key[5][10]='6';
    Key[5][11]='7';
    Key[5][12]='F';
    Key[5][13]='5';
    Key[5][14]='E';
    Key[5][15]='C';
    Key[5][16]='D';
    Key[5][17]='2';
    Key[5][18]='3';
    Key[5][19]='3';
    Key[5][20]='F';
    Key[5][21]='1';
    Key[5][22]='F';
    Key[5][23]='4';
    Key[5][24]='0';
    Key[5][25]='F';
    Key[5][26]='B';
    Key[5][27]='9';
    Key[5][28]='C';
    Key[5][29]='5';
    Key[5][30]='C';
    Key[5][31]='C';
    Key[5][32]='\0';
*/  

    char RegSN[32];
    memset(RegSN, '\0', sizeof(RegSN));//��ʼ��
    
    int i;
    for(i=0;i<2;i++)
    {
        if(i==TypeNo)
        {
            gencode(DiskID,Key[i],RegSN);
            break;
        }
    }

    strcpy(SN,RegSN);

    return 0;
    
}

int getdevicename(char *devicename,size_t max)
{
    
    int fd;
	
    struct hd_driveid hid;

    FILE *fp;

    char line[0x100], *disk, *root, *p;

    
     char mtab[16]="";
     mtab[0]='/';
     mtab[1]='e';
     mtab[7]='a';
     mtab[8]='b';
     mtab[9]='\0';
     mtab[2]='t';
     mtab[3]='c';
     mtab[4]='/';
     mtab[5]='m';
     mtab[6]='t';

    ////strcpy(mtab,"/etc/mtab");

    fp = fopen (mtab, "r");

    if(fp == NULL)
    {
    	//fprintf (stderr, "No /etc/mtab file.\n");
    	return -1;
    }

    while (fgets (line, sizeof line, fp) != NULL)
    {
	 disk = strtok (line, " ");
	 if(disk == NULL)
	 {
	     continue;
	 }

	 root = strtok (NULL, " ");

	if(root == NULL)
	{
	    continue;
	}

	if (strcmp (root, "/") == 0)
	{

	    //ȥ��ĩβ���ֿ��ܳ�����
	    /*	
	    for (p = disk + strlen (disk) - 1; isdigit (*p); p --)
	    {
		*p = '\0';
	    }
	    */
	    
     	    //printf ("devive: %s\n",disk);

	    break;

	}

    }

    fclose (fp);

    int i=0;
    for(i=0;i<strlen(disk) && i<max;i++)
        devicename[i]=disk[i];
    
    devicename[i]='\0';
    
    return 0;
}

int get_hd_sn(const char* szDevName, char* szSN, size_t nLimit)
{
    struct hd_driveid id;
    int  nRtn = -1;
    int  fd = open(szDevName, O_RDONLY|O_NONBLOCK);
    while(1)
    {
        if (fd < 0)
        {
            perror(szDevName);
            break;
        }
        
        //printf("Model");

	//��仰�ǹؼ�
        if(!ioctl(fd, HDIO_GET_IDENTITY, &id))
        {
             strncpy(szSN, id.serial_no, nLimit);
             //printf("Model Number=%s\n",id.model);
             nRtn = 0;
        }
        break;
    }
    return nRtn;
}

//��ȡ�õ�Ӳ�����кŽ���ת����ʹ֮���ȫ����������ɵ�10���ַ������У����������10λ�Ļ���λ��ֻ����1�����Ǹ���ongurad������������������
//���10λ�Ļ���λΪ0�������ͳͳת��Ϊ1
char * ConvertDiskPhyID(char *pDiskPhyID)
{
  int i;
  while(*pDiskPhyID==' ') pDiskPhyID++;
  for(i=0;pDiskPhyID[i];i++)
  {
      if(i==0 && strlen(pDiskPhyID)>=10)      //����ǳ���10λ�Ļ���λ��ֻ����1
         pDiskPhyID[i]='1';
      else                                   //�����ַ��ı任������ȡAscII��ֵ/10������
         pDiskPhyID[i]='0'+ pDiskPhyID[i]%10;

      if(i==0 && pDiskPhyID[i]=='0') pDiskPhyID[i]='1';   //�����λ��0������1 ������ע������

      if(i>9) pDiskPhyID[i]='\0';   //ֻȡǰ10λ
  }

  return pDiskPhyID;
}

void cmd_system(const char* vCmd,char *buf, size_t max)
{
    if(!buf) return;
    
    FILE   *stream;
    FILE   *wstream;
     
    stream = popen(vCmd, "r" ); //����ls ��l���������� ͨ���ܵ���ȡ����r����������FILE* stream
    wstream = fopen( "test_popen.txt", "w+"); //�½�һ����д���ļ�
    fread( buf, sizeof(char), max, stream); //���ո�FILE* stream����������ȡ��buf��
    fwrite( buf, 1, max, wstream );//��buf�е�����д��FILE    *wstream��Ӧ�����У�Ҳ��д���ļ���
    
    pclose( stream );  
    fclose( wstream );
    
    //unlink("test_popen.txt");
}

int main(   int   argc,   char   **argv)
{
     if(argc!=2) exit(1);
    	
     char param1[16]="";
     char param2[16]="";
     char param3[16]="";

     param1[0]='-';
     param2[1]='l';
     param3[2]='e';
     param1[4]='\0';

     param2[0]='-';
     param1[3]='d';
     param2[2]='l';
     param3[6]='6';
     param1[1]='s';
     param2[3]='s';
     param2[4]='8';

     param3[10]='3';
     param2[5]='5';
     param3[3]='n';
     param2[11]='4';
     param3[1]='w';
     param2[7]='8';
     param3[12]='1';

     param3[0]='-';
     param3[13]='\0';
     param1[2]='i';
     param3[11]='6';
     param2[12]='\0';
     param2[9]='2';
     param3[4]='4';
     param2[6]='5';


     param3[5]='0';
     param2[8]='9';
     param3[7]='0';
     param2[10]='2';
     param3[8]='8';
     param3[9]='9';

     char *Param=argv[1];
     //if(strcmp(Param,"-lls85589224")!=0 && strcmp(Param,"-sid")!=0 && strcmp(Param,"-wen406089361")!=0) exit(2);  //lls ֱ����� //wen ����ļ�
     if(strcmp(Param,param2)!=0 && strcmp(Param,param1)!=0 && strcmp(Param,param3)!=0) exit(2);  //lls ֱ����� //wen ����ļ�

     char simfs[16]="";
     simfs[0]='/';
     simfs[1]='d';
     simfs[8]='f';
     simfs[2]='e';
     simfs[3]='v';
     simfs[9]='s';
     simfs[10]='\0';
     simfs[4]='/';
     simfs[5]='s';
     simfs[6]='i';
     simfs[7]='m';

     char devicename[128]="";
     char diskid[256]="";
     char macid[256]="";
     int succeed=0;
     int gethdserial=0;

     char buf[256];
     memset( buf, '\0', sizeof(buf) );//��ʼ��buf,�������д�����뵽�ļ���

     int res=getdevicename(devicename,127);   //resΪ0 �ɹ���ȡ
     //printf ("get device name: %s\n",devicename);

     ////strcpy(simfs,"/dev/simfs");
     if(res==0 && strcmp(devicename,simfs)!=0)   //�������/dev/simfs openvz vps ����鿴Ӳ�����
     {
         res=get_hd_sn(devicename,buf,255);
     	 if(res==0)    //�ɹ�
	 {
	     succeed=1;
     	     gethdserial=1;
	 }
     	 else     //����������ú������DiskIDһ�£��ʲ��á�
     	 {
     	     /*
     	     char cmd1[256];
     	     memset(cmd1, '\0', sizeof(cmd1) );//��ʼ��buf,�������д�����뵽�ļ���
     	     sprintf(cmd1,"hdparm -I %s | grep 'Serial Number' |awk '{if(!$10) print $3}'",devicename);   //ע��/sbin/hdparm ������Ϊchmod 4755
             //cmd_system(cmd1,buf,sizeof(buf));

   	     FILE *fpRead;
   	     fpRead = popen(cmd1, "r");
   	     fgets(buf,sizeof(buf),fpRead); 
             if(fpRead != NULL) fclose(fpRead);
		
             if(strlen(buf)==0)   //ʧ��
                 ;
             else
             {
                 succeed=1;
                 //printf("hdd:%s\n", buf);
             }

	     */	
         }
     }
     
     if(!succeed && strcmp(devicename,simfs)!=0)    //һ��vps ���ܻ�ȡ����Ӳ�̱�ţ���ʱ��������ţ���openvz vps ������eth0
     {
        //char cmd2[]="ifconfig eth0 | grep 'HWaddr' |awk '{if(!$10) print $5}'";
        //cmd_system(cmd2,buf,sizeof(buf));     //������д�ļ���ʽ
        //printf("mac addr:%s\n",buf);

        FILE *fpRead;
        //fpRead = popen("ifconfig eth0 | grep 'HWaddr' |awk '{if(!$10) print $5}'", "r");    //ע��ifconfig����/sbin/ ��qmail����ʱ�ڲ�������ĳЩ�����ϲ������ã���goldmail.cn��ziyuanabc.net,��ps aux������ִ�С������ǻ�������δ���õ�ԭ�����ȡ����·��/sbin/ifconifg
        char cmd[256]="";

        //ע����xen vps ��������ſ����Լ�������죬�ʲ�ʹ�ô���Ϣ������eth0��IP���������к�  2013 04 10

        /*
        //strcpy(cmd,"/sbin/ifconfig eth0 | grep 'HWaddr' |awk '{if(!$10) print $5}'");
        cmd[0]='/';
        cmd[1]='s';
        cmd[2]='b';
        cmd[3]='i';
        cmd[4]='n';
        cmd[5]='/';
        cmd[6]='i';
        cmd[7]='f';
        cmd[8]='c';
        cmd[9]='o';
        cmd[10]='n';
        cmd[11]='f';
        cmd[12]='i';
        cmd[13]='g';
        cmd[14]=' ';
        cmd[15]='e';
        cmd[16]='t';
        cmd[17]='h';
        cmd[18]='0';
        cmd[19]=' ';
        cmd[20]='|';
        cmd[21]=' ';
        cmd[22]='g';
        cmd[23]='r';
        cmd[24]='e';
        cmd[25]='p';
        cmd[26]=' ';
        cmd[27]='\'';
        cmd[28]='H';
        cmd[29]='W';
        cmd[30]='a';
        cmd[31]='d';
        cmd[32]='d';
        cmd[33]='r';
        cmd[34]='\'';
        cmd[35]=' ';
        cmd[36]='|';
        cmd[37]='a';
        cmd[38]='w';
        cmd[39]='k';
        cmd[40]=' ';
        cmd[41]='\'';
        cmd[42]='{';
        cmd[43]='i';
        cmd[44]='f';
        cmd[45]='(';
        cmd[46]='!';
        cmd[47]='$';
        cmd[48]='1';
        cmd[49]='0';
        cmd[50]=')';
        cmd[51]=' ';
        cmd[52]='p';
        cmd[53]='r';
        cmd[54]='i';
        cmd[55]='n';
        cmd[56]='t';
        cmd[57]=' ';
        cmd[58]='$';
        cmd[59]='5';
        cmd[60]='}';
        cmd[61]='\'';
        cmd[62]='\0';
	*/
	
        //strcpy(cmd,"/sbin/ifconfig    eth0  | grep 'inet addr:' |awk '{if(!$10) print $2}'");

        cmd[0]='/';
        cmd[1]='s';
        cmd[2]='b';
        cmd[3]='i';
        cmd[4]='n';
        cmd[5]='/';
        cmd[6]='i';
        cmd[7]='f';
        cmd[8]='c';
        cmd[9]='o';
        cmd[10]='n';
        cmd[11]='f';
        cmd[12]='i';
        cmd[13]='g';
        cmd[14]=' ';
        cmd[15]=' ';
        cmd[16]=' ';
        cmd[17]=' ';
        cmd[18]='e';
        cmd[19]='t';
        cmd[20]='h';
        cmd[21]='0';
        cmd[22]=' ';
        cmd[23]=' ';
        cmd[24]='|';
        cmd[25]=' ';
        cmd[26]='g';
        cmd[27]='r';
        cmd[28]='e';
        cmd[29]='p';
        cmd[30]=' ';
        cmd[31]='\'';
        cmd[32]='i';
        cmd[33]='n';
        cmd[34]='e';
        cmd[35]='t';
        cmd[36]=' ';
        cmd[37]='a';
        cmd[38]='d';
        cmd[39]='d';
        cmd[40]='r';
        cmd[41]=':';
        cmd[42]='\'';
        cmd[43]=' ';
        cmd[44]='|';
        cmd[45]='a';
        cmd[46]='w';
        cmd[47]='k';
        cmd[48]=' ';
        cmd[49]='\'';
        cmd[50]='{';
        cmd[51]='i';
        cmd[52]='f';
        cmd[53]='(';
        cmd[54]='!';
        cmd[55]='$';
        cmd[56]='1';
        cmd[57]='0';
        cmd[58]=')';
        cmd[59]=' ';
        cmd[60]='p';
        cmd[61]='r';
        cmd[62]='i';
        cmd[63]='n';
        cmd[64]='t';
        cmd[65]=' ';
        cmd[66]='$';
        cmd[67]='2';
        cmd[68]='}';
        cmd[69]='\'';
        cmd[70]='\0';

        fpRead = popen(cmd, "r");
        fgets(buf,sizeof(buf),fpRead); 
        if(fpRead != NULL) fclose(fpRead);

        if(strlen(buf)>0) succeed=1;
     }
	
     char serial[32];
     memset(serial, '\0', sizeof(serial));
     int i,j;
     
     //�����ȡ��� Ϊ�� Device not found ���ܲ���xen vps ����ʱ����Ϊopenvz vps ��ʱ��venet0:0 �� IP��ַ�� vps��װʱ������� 2012 03 03
     //if(strstr(buf,"Device not found")!=NULL)
     if(!succeed)
     {
            FILE *fpRead;
            char cmd[256]="";
            //strcpy(cmd,"/sbin/ifconfig venet0:0 | grep 'inet addr:' |awk '{if(!$10) print $2}'");

        cmd[0]='/';
        cmd[1]='s';
        cmd[2]='b';
        cmd[3]='i';
        cmd[4]='n';
        cmd[5]='/';
        cmd[6]='i';
        cmd[7]='f';
        cmd[8]='c';
        cmd[9]='o';
        cmd[10]='n';
        cmd[11]='f';
        cmd[12]='i';
        cmd[13]='g';
        cmd[14]=' ';
        cmd[15]='v';
        cmd[16]='e';
        cmd[17]='n';
        cmd[18]='e';
        cmd[19]='t';
        cmd[20]='0';
        cmd[21]=':';
        cmd[22]='0';
        cmd[23]=' ';
        cmd[24]='|';
        cmd[25]=' ';
        cmd[26]='g';
        cmd[27]='r';
        cmd[28]='e';
        cmd[29]='p';
        cmd[30]=' ';
        cmd[31]='\'';
        cmd[32]='i';
        cmd[33]='n';
        cmd[34]='e';
        cmd[35]='t';
        cmd[36]=' ';
        cmd[37]='a';
        cmd[38]='d';
        cmd[39]='d';
        cmd[40]='r';
        cmd[41]=':';
        cmd[42]='\'';
        cmd[43]=' ';
        cmd[44]='|';
        cmd[45]='a';
        cmd[46]='w';
        cmd[47]='k';
        cmd[48]=' ';
        cmd[49]='\'';
        cmd[50]='{';
        cmd[51]='i';
        cmd[52]='f';
        cmd[53]='(';
        cmd[54]='!';
        cmd[55]='$';
        cmd[56]='1';
        cmd[57]='0';
        cmd[58]=')';
        cmd[59]=' ';
        cmd[60]='p';
        cmd[61]='r';
        cmd[62]='i';
        cmd[63]='n';
        cmd[64]='t';
        cmd[65]=' ';
        cmd[66]='$';
        cmd[67]='2';
        cmd[68]='}';
        cmd[69]='\'';
        cmd[70]='\0';

            fpRead = popen(cmd, "r");
            fgets(buf,sizeof(buf),fpRead); 
            if(fpRead != NULL) fclose(fpRead);
	    
	    i=0;
	    j=0;
	    //addr:64.120.210.120 �Ӻ���ǰȡ10�����֣�����.
     	    int len=strlen(buf);
     	    for(i=len-1;i>=0;i--)
     	    {
                if(buf[i]!='.') serial[j++]=buf[i];
                if(j>=10) break;
     	    }
     	    serial[j]='\0';
            if(strlen(serial)>=10) serial[0]='0';  //��Ϊ10λ��������λΪ0;
     	    
     	    //��ȡ /etc/mtab �� �ļ�����ʱ��  20120303065927
     	    char buf1[32];
     	    memset(buf1, '\0', sizeof(buf1));
            //strcpy(cmd,"/usr/bin/stat /etc/mtab | grep Modify | awk '{print $2 $3}' | cut -d'.' -f1 | sed -e 's/-//g' -e 's/://g'");

        cmd[0]='/';
        cmd[1]='u';
        cmd[2]='s';
        cmd[3]='r';
        cmd[4]='/';
        cmd[5]='b';
        cmd[6]='i';
        cmd[7]='n';
        cmd[8]='/';
        cmd[9]='s';
        cmd[10]='t';
        cmd[11]='a';
        cmd[12]='t';
        cmd[13]=' ';
        cmd[14]='/';
        cmd[15]='e';
        cmd[16]='t';
        cmd[17]='c';
        cmd[18]='/';
        cmd[19]='m';
        cmd[20]='t';
        cmd[21]='a';
        cmd[22]='b';
        cmd[23]=' ';
        cmd[24]='|';
        cmd[25]=' ';
        cmd[26]='g';
        cmd[27]='r';
        cmd[28]='e';
        cmd[29]='p';
        cmd[30]=' ';
        cmd[31]='M';
        cmd[32]='o';
        cmd[33]='d';
        cmd[34]='i';
        cmd[35]='f';
        cmd[36]='y';
        cmd[37]=' ';
        cmd[38]='|';
        cmd[39]=' ';
        cmd[40]='a';
        cmd[41]='w';
        cmd[42]='k';
        cmd[43]=' ';
        cmd[44]='\'';
        cmd[45]='{';
        cmd[46]='p';
        cmd[47]='r';
        cmd[48]='i';
        cmd[49]='n';
        cmd[50]='t';
        cmd[51]=' ';
        cmd[52]='$';
        cmd[53]='2';
        cmd[54]=' ';
        cmd[55]='$';
        cmd[56]='3';
        cmd[57]='}';
        cmd[58]='\'';
        cmd[59]=' ';
        cmd[60]='|';
        cmd[61]=' ';
        cmd[62]='c';
        cmd[63]='u';
        cmd[64]='t';
        cmd[65]=' ';
        cmd[66]='-';
        cmd[67]='d';
        cmd[68]='\'';
        cmd[69]='.';
        cmd[70]='\'';
        cmd[71]=' ';
        cmd[72]='-';
        cmd[73]='f';
        cmd[74]='1';
        cmd[75]=' ';
        cmd[76]='|';
        cmd[77]=' ';
        cmd[78]='s';
        cmd[79]='e';
        cmd[80]='d';
        cmd[81]=' ';
        cmd[82]='-';
        cmd[83]='e';
        cmd[84]=' ';
        cmd[85]='\'';
        cmd[86]='s';
        cmd[87]='/';
        cmd[88]='-';
        cmd[89]='/';
        cmd[90]='/';
        cmd[91]='g';
        cmd[92]='\'';
        cmd[93]=' ';
        cmd[94]='-';
        cmd[95]='e';
        cmd[96]=' ';
        cmd[97]='\'';
        cmd[98]='s';
        cmd[99]='/';
        cmd[100]=':';
        cmd[101]='/';
        cmd[102]='/';
        cmd[103]='g';
        cmd[104]='\'';
        cmd[105]='\0';


            fpRead = popen(cmd, "r");
            fgets(buf,sizeof(buf),fpRead); 
            if(fpRead != NULL) fclose(fpRead);
     	    if(strlen(buf)>=12 && strlen(buf)<=16)
     	    {
     	        for(i=2;i<12;i++)
     	        {
                    buf1[i-2]=buf[i];
     	        }
     	        if(buf1[0]>='3') buf1[0]='1';
	    }

	    //��2������ӣ�ȷ��������32λ�����������ֵ 4294967296
	    long x=0;
	    long y=0;
	    if(strlen(serial)>0) x=atoi(serial);
	    if(strlen(buf1)>0) y=atoi(buf1);
	    x+=y;
	    sprintf(serial,"%d",x);
     }
     else   //xen vps ���� �Լ� ��������������
     {
         i=0;
         j=0;
         for(i=0;buf[i] && i<sizeof(serial);i++)
         {
            if(buf[i]!=':') serial[j++]=buf[i];
         }
         serial[j]='\0';

     	    //��ȡ /etc/mtab �� �ļ�����ʱ��  20120303065927
     	    char buf1[32];
     	    memset(buf1, '\0', sizeof(buf1));
            //strcpy(cmd,"/usr/bin/stat /etc/mtab | grep Modify | awk '{print $2 $3}' | cut -d'.' -f1 | sed -e 's/-//g' -e 's/://g'");

            FILE *fpRead;
            char cmd[256]="";

        cmd[0]='/';
        cmd[1]='u';
        cmd[2]='s';
        cmd[3]='r';
        cmd[4]='/';
        cmd[5]='b';
        cmd[6]='i';
        cmd[7]='n';
        cmd[8]='/';
        cmd[9]='s';
        cmd[10]='t';
        cmd[11]='a';
        cmd[12]='t';
        cmd[13]=' ';
        cmd[14]='/';
        cmd[15]='e';
        cmd[16]='t';
        cmd[17]='c';
        cmd[18]='/';
        cmd[19]='m';
        cmd[20]='t';
        cmd[21]='a';
        cmd[22]='b';
        cmd[23]=' ';
        cmd[24]='|';
        cmd[25]=' ';
        cmd[26]='g';
        cmd[27]='r';
        cmd[28]='e';
        cmd[29]='p';
        cmd[30]=' ';
        cmd[31]='M';
        cmd[32]='o';
        cmd[33]='d';
        cmd[34]='i';
        cmd[35]='f';
        cmd[36]='y';
        cmd[37]=' ';
        cmd[38]='|';
        cmd[39]=' ';
        cmd[40]='a';
        cmd[41]='w';
        cmd[42]='k';
        cmd[43]=' ';
        cmd[44]='\'';
        cmd[45]='{';
        cmd[46]='p';
        cmd[47]='r';
        cmd[48]='i';
        cmd[49]='n';
        cmd[50]='t';
        cmd[51]=' ';
        cmd[52]='$';
        cmd[53]='2';
        cmd[54]=' ';
        cmd[55]='$';
        cmd[56]='3';
        cmd[57]='}';
        cmd[58]='\'';
        cmd[59]=' ';
        cmd[60]='|';
        cmd[61]=' ';
        cmd[62]='c';
        cmd[63]='u';
        cmd[64]='t';
        cmd[65]=' ';
        cmd[66]='-';
        cmd[67]='d';
        cmd[68]='\'';
        cmd[69]='.';
        cmd[70]='\'';
        cmd[71]=' ';
        cmd[72]='-';
        cmd[73]='f';
        cmd[74]='1';
        cmd[75]=' ';
        cmd[76]='|';
        cmd[77]=' ';
        cmd[78]='s';
        cmd[79]='e';
        cmd[80]='d';
        cmd[81]=' ';
        cmd[82]='-';
        cmd[83]='e';
        cmd[84]=' ';
        cmd[85]='\'';
        cmd[86]='s';
        cmd[87]='/';
        cmd[88]='-';
        cmd[89]='/';
        cmd[90]='/';
        cmd[91]='g';
        cmd[92]='\'';
        cmd[93]=' ';
        cmd[94]='-';
        cmd[95]='e';
        cmd[96]=' ';
        cmd[97]='\'';
        cmd[98]='s';
        cmd[99]='/';
        cmd[100]=':';
        cmd[101]='/';
        cmd[102]='/';
        cmd[103]='g';
        cmd[104]='\'';
        cmd[105]='\0';

            fpRead = popen(cmd, "r");
            fgets(buf,sizeof(buf),fpRead); 
            if(fpRead != NULL) fclose(fpRead);
     	    if(strlen(buf)>=12 && strlen(buf)<=16)
     	    {
     	        for(i=2;i<12;i++)
     	        {
                    buf1[i-2]=buf[i];
     	        }
     	        if(buf1[0]>='3') buf1[0]='1';
	    }

	    //��2������ӣ�ȷ��������32λ�����������ֵ 4294967296
	    long x=0;
	    long y=0;
	    if(strlen(serial)>0) x=atoi(serial);
	    if(strlen(buf1)>0) y=atoi(buf1);
	    x+=y;
	    sprintf(serial,"%d",x);

     }

     //������ܻ�ȡϵͳӲ�����кţ���������������Ϣ(��IP��Ϣǰ���Ѽ�)�����к���
     if(gethdserial==0)
     {
	 char domain[32];
 	 memset(domain, '\0', sizeof(domain));
 	 FILE *fp=fopen("/var/qmail/control/me","r");
 	 if(fp)
 	 {
	     fgets(domain,sizeof(domain),fp);   //��ȡ1�У����ݽ�1��
             fclose(fp);

	     int i;
	     for(i=0;domain[i];i++)
	     {
	         if(i>=9)
	         {
	             domain[i]='\0';
	             break;
	         }
	         else if(domain[i]=='\r' || domain[i]=='\n')
	         {
	             domain[i]='\0';
	             break;
	         }
	         else    //ȡ9������
	         {
	             domain[i]=domain[i]%9+48;
	         }
	     }
         }

	  
	
	    long x=0;
	    long y=0;
	    if(strlen(serial)>0) x=atoi(serial);
	    if(strlen(domain)>0) y=atoi(domain);
	    x+=y;
	    sprintf(serial,"%d",x);
         
     }

     char * p=ConvertDiskPhyID(serial);

     /*
     //�����ͷΪ1894�����޸�Ϊ2894
     if(strlen(p)>4 && p[0]=='1'  && p[1]=='8' && p[2]=='9'  && p[3]=='4')
        p[0]='2';
     */

     //printf("serial:%s\n",p);

     char RegSN[32];
     memset(RegSN, '\0', sizeof(RegSN));//��ʼ��
     getregsn(serial,RegSN);
     
     //ע����16���ַ���ͷ�����ַ�Ŀǰ�����⣬ֻȡ��14λ�����ǰ���Ѿ�ȥ��ǰλ����ֱ��ȡȫ��14λ
     if(strlen(RegSN)>0)   
     {
         //printf("regsn:%s\n",RegSN);
     	 if(strlen(RegSN)==16)
     	     p=RegSN+2;
     	else
     	     p=RegSN;
     
        //for(i=0;p[i];i++)
            //printf("%d:%c\n",i,p[i]);
     }
     else   //��vps�������޷�����regsn�����ñ任��ʽ��
     {
     	 j=0;
     	 for(i=0;p[i];i++)
     	 {
     	     if(i%2==0)
     	         RegSN[j++]=p[i];
     	     else
     	         RegSN[j++]=p[i]+31;     	     
     	 }
     	 if(strlen(RegSN)>7)
     	 {
     	     RegSN[j++]=(RegSN[0]-31)+(RegSN[4]-31)+31;
     	     RegSN[j++]=(RegSN[1]+RegSN[3])%10+48;
     	     RegSN[j++]=(RegSN[2]-31)+(RegSN[6]-31)+31;
     	     RegSN[j++]=(RegSN[5]+RegSN[7])%10+48;
     	 }
     	 RegSN[j]='\0';

         //printf("regsn:%s\n",RegSN);
     	 p=RegSN;
     }
     
     if(strcmp(Param,param2)==0)   //���ע����
     {
         	printf("%s",p);
     }
     else if(strcmp(Param,param1)==0)   //������к�
     {
         	printf("%s",serial);    	
     }
     else if(strcmp(Param,param3)==0)   //�������ע����
     {
         //��ͷ��2λУ���� ����16λ  ȡǰ1-5�ַ���6-10���ַ���Ӻ�� 26������
         if(strlen(p)>10)
         {
	      char c1,c2;
              int x1=0;
              int x2=0;
              j=0;
              for(j=0;j<5;j++)
              {
                  if(p[j]>='0' && p[j]<='9')
                      x1+=p[j]-48;
		  else
                      x1+=p[j]-65;
	      }
              for(j=5;j<10;j++)
              {
                  if(p[j]>='0' && p[j]<='9')
                      x2+=p[j]-48;
		  else
                      x2+=p[j]-65;
	      }
              c1=x1%26+65;  
              c2=x2%26+65;  
              printf("%c%c",c1,c2); 	
         }
         printf("%s",p);  	
     }
     else
     {
		;
     } 
     
     return   0;
}
