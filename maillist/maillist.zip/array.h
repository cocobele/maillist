#ifndef ARRAY_H
#define ARRAY_H

template<typename T>class Array
{
private:
    T* parray;                //���嶯̬����
    int room;                //�洢�ռ��С��ֵ
public:
    Array()
        :room    (0)
        ,parray    (NULL)
    {
        parray=(int*)malloc(sizeof(int)*room);
    }
    ~Array()
    {
        if(parray!=NULL)
            free(parray);
    }
    int push_back(T m)        //����һ������Ԫ��
    {
        room++;
        parray=(T*)realloc(parray,sizeof(T)*room);
        *(parray+room-1)=m;
        return *(parray+room-1);
    }
    int sizeof_Array()            //�õ������С
    {
        return room;
    }
    bool remove(int k)            //ɾ����k��Ԫ��
    {
        printf("ɾ��Ԫ��%d�� ",k);
        if(k>room-1 || k<0)
        {
            return false;
        }
        else
        {
            memmove(parray+k,parray+k+1,sizeof(T)*(room-1-k));
            room-=1;
            return true;
        }
    }
    bool insert(int k,T element)        //����һ��Ԫ��
    {
        printf("����Ԫ��%d�� ",k);
        if(k>room || k<0)
        {
            return false;
        }
        else
        {
            room++;
            parray=(T*)realloc(parray,sizeof(T)*room);
            memmove(parray+k+1,parray+k,sizeof(T)*(room-1-k));
            *(parray+k)=element;
        }
    }
    T query(int k)                //��ѯ��k��Ԫ�ص�ֵ
    {
        if(k>room-1 || k<0)
        {
            return -1;
        }
        else
        {
            return *(parray+k);
        }
    }
    void display()                //��ʾ������Ԫ�ظ���
    {
        for(int i=0;i<room;i++)
            cout<<query(i)<<endl;
        cout<<"������Ԫ�ظ���"<<sizeof_Array()<<endl;
    }
    T* begin()
    {
        return parray;
    }
    T* end()
    {
        return parray + room;
    }
};
#endif